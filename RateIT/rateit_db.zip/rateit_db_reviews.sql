CREATE DATABASE  IF NOT EXISTS `rateit_db` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rateit_db`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: rateit_db
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `company_id` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `feedback` text,
  `rate` int DEFAULT NULL,
  `photo` text,
  `show` tinyint DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_reviews_users1_idx` (`user_id`),
  KEY `fk_reviews_companies1_idx` (`company_id`),
  CONSTRAINT `fk_reviews_companies1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_reviews_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (3,2,2,'Un trés bon hotel','sejour yesser hayel surtt coté mekla',5,'edit.png',1,'2023-06-10 10:14:54','2023-06-10 10:14:54'),(5,3,1,'I\'m there','Good place to learn',4,'3024068.jpg',1,'2023-06-12 19:39:48','2023-06-12 19:39:48'),(7,1,2,'Cool','un très bon hotel',4,'',1,'2023-06-13 09:25:36','2023-06-14 13:41:22'),(8,4,1,'title','buzbefbzenfknzke,f',5,'',1,'2023-06-13 10:04:12','2023-06-13 10:04:12'),(9,5,6,'sdfvbngfb','sdgnfhndfbfvdvef',1,'3024068.jpg',1,'2023-06-13 11:54:40','2023-06-13 11:54:40'),(10,2,3,'Ndhif','mlkjhjjgklhgftyk iolghjjuiop olihyuibjnpo oimougctygyujo ',3,'3024068.jpg',1,'2023-06-14 09:44:53','2023-06-14 09:44:53'),(11,2,3,'dstyter','ezty reytery',5,'3024068.jpg',1,'2023-06-14 15:10:08','2023-06-14 15:10:08'),(12,6,1,'Hard but so cool','The bootcamp was like a sprint after 8h of woking algos lecture you have also you homework as assignments between core and practice you will feel exhausted but satisfied with what you have done',5,'3024068.jpg',1,'2023-06-15 22:46:48','2023-06-15 22:46:48'),(13,2,8,'don\'t know','always so quiet there!',2,'4CV.jpg',1,'2023-06-16 00:54:10','2023-06-16 00:54:10'),(14,2,1,'sfdgfg','sfdegfef zefefe',5,'edit.png',1,'2023-06-16 10:30:52','2023-06-16 10:30:52'),(15,1,10,'Heyla','mekla tayara ndhifa w bnina',5,'bna.png',1,'2023-06-19 08:49:48','2023-06-19 20:51:57');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-20  9:05:20
