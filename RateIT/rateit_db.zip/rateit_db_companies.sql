CREATE DATABASE  IF NOT EXISTS `rateit_db` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rateit_db`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: rateit_db
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sector_id` int NOT NULL,
  `adress_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `logo` text,
  `site` varchar(125) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `password` char(125) DEFAULT NULL,
  `mf` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `adress_id_UNIQUE` (`adress_id`),
  KEY `fk_companies_categories_idx` (`sector_id`),
  KEY `fk_companies_adresses1_idx` (`adress_id`),
  CONSTRAINT `fk_companies_adresses1` FOREIGN KEY (`adress_id`) REFERENCES `adresses` (`id`),
  CONSTRAINT `fk_companies_categories` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,1,1,'CodingDojo','cd.png','codingdojo.com','dojo@email.com','$2b$12$Su0DO4XSaC3454hDvqWw1O0a/1Z4U2j84gYpnJ8YYwv/GdLNwtqiS','mf123456','2023-06-09 18:28:29','2023-06-18 12:03:45'),(2,3,2,'Sentido','sentido.png','sentido.com','sentido@email.com','$2b$12$LMFQzMiTbX5sGZqEqA436ep99AHuanWO.SKPe33CQomXuHrpkwJLm','123456','2023-06-09 19:20:15','2023-06-18 12:09:08'),(3,2,3,'Clinique Jasmin','cliniqueJasmin.png','jasmin.com','jasmin@email.com','$2b$12$HamjDENJpkd41M0LKPb3BuMvDEzQszAtPSm3bnrT7ZjZJHgW39pZ.','104253','2023-06-09 19:21:49','2023-06-19 20:07:11'),(5,2,5,'Mohamed El Kahla',NULL,'santidljlko.com','elkahla432432742med@gmail.com','$2b$12$rJeA6ohH9yOtJTIpfGvT3eFJZruXd8WJ1HxCjbAVI7LNrv4EAlbUO','51651651','2023-06-12 10:07:00','2023-06-12 10:07:00'),(6,8,6,'VIENNE',NULL,'vienne.com','vienne@email.com','$2b$12$aDlOHC1hK31fx9QPVmmwH.iLd8eWQZScgq5S61hEngFF60p9m1yEO','lkkjbd6813256','2023-06-12 20:28:22','2023-06-12 20:28:22'),(8,10,8,'Fablab',NULL,'fablab.com','fablab@email.com','$2b$12$gr37I23S6iLsFk6VsAua1uKHN1Bhkncc/5.oYzlcgumlrleJZzwk2','6513sdqf','2023-06-13 11:56:59','2023-06-18 15:20:31'),(10,11,9,'PlanB','planb.png','www.plan-b.com.tn','planb@email.com','$2b$12$Gcehw3AUwZ/qiGGYfZNSX.uvAc2KOfk07sQ8YqG97sBDvSlpfyswy','sdf65316','2023-06-18 13:20:54','2023-06-18 14:50:49');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-20  9:05:21
